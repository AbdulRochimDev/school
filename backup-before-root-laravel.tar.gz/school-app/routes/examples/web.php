<?php

use Illuminate\Support\Facades\Route;

Route::get('/', fn() => 'School Management');

