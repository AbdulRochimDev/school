<?php

require __DIR__.'/examples/web.php';

