<?php

require __DIR__.'/examples/api.php';
if (is_file(__DIR__.'/api_attendance.php')) require __DIR__.'/api_attendance.php';
if (is_file(__DIR__.'/api_assignments.php')) require __DIR__.'/api_assignments.php';

