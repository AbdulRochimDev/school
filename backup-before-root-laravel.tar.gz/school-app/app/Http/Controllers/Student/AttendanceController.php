<?php
namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\{AttendanceRecord};

class AttendanceController extends Controller
{
    public function summary()
    {
        $studentId = auth()->user()->student->id ?? null;
        abort_unless($studentId, 403);
        $q = AttendanceRecord::where('student_id', $studentId);
        return [
            'present' => (clone $q)->where('status','present')->count(),
            'late' => (clone $q)->where('status','late')->count(),
            'excused' => (clone $q)->where('status','excused')->count(),
            'absent' => (clone $q)->where('status','absent')->count(),
        ];
    }
}

