<?php
namespace App\Listeners;

use App\Events\AttendanceSessionClosed;
use App\Models\{AttendanceRecord, AttendanceSession, Enrollment, Grade, GradeItem};
use App\Services\AttendanceScoreService;
use Illuminate\Support\Facades\DB;

class RecomputeAttendanceGrades
{
    public function handle(AttendanceSessionClosed $event): void
    {
        $session = $event->session;
        $csId = $session->class_subject_id;
        if (!$csId) return;

        DB::transaction(function () use ($session, $csId) {
            $gradeItem = GradeItem::firstOrCreate(
                ['class_subject_id' => $csId, 'name' => 'Attendance'],
                ['weight' => 10, 'max_score' => 100]
            );

            $studentIds = Enrollment::where('class_id', $session->class_id)->pluck('student_id');
            $tot = AttendanceSession::where('class_subject_id', $csId)->where('status', 'closed')->count();
            if ($tot == 0) return;

            foreach ($studentIds as $sid) {
                $present = AttendanceRecord::whereHas('session', function ($q) use ($csId) {
                    $q->where('class_subject_id', $csId)->where('status', 'closed');
                })->where('student_id', $sid)->where('status', 'present')->count();
                $late = AttendanceRecord::whereHas('session', function ($q) use ($csId) {
                    $q->where('class_subject_id', $csId)->where('status', 'closed');
                })->where('student_id', $sid)->where('status', 'late')->count();
                $excused = AttendanceRecord::whereHas('session', function ($q) use ($csId) {
                    $q->where('class_subject_id', $csId)->where('status', 'closed');
                })->where('student_id', $sid)->where('status', 'excused')->count();

                $score = app(AttendanceScoreService::class)->calculate($present, $late, $excused, $tot);
                Grade::updateOrCreate(
                    ['grade_item_id' => $gradeItem->id, 'student_id' => $sid],
                    ['score' => $score, 'graded_at' => now()]
                );
            }
        });
    }
}
