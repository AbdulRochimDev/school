<?php
namespace App\Listeners;

use App\Events\GradesUpdated;
use App\Models\{ReportCard, ReportCardItem, GradeItem, Grade};

class UpdateReportCards
{
    public function handle(GradesUpdated $event): void
    {
        // Minimal stub: ensure a ReportCard exists for each student
        foreach ($event->studentIds as $sid) {
            $rc = ReportCard::firstOrCreate(['student_id' => $sid, 'term_id' => $event->termId]);
            // Optional: recompute aggregates if grade items exist
            $items = GradeItem::query()->get();
            $total = 0; $weights = 0;
            foreach ($items as $gi) {
                $g = Grade::where('grade_item_id', $gi->id)->where('student_id', $sid)->first();
                if (!$g) continue;
                ReportCardItem::updateOrCreate(
                    ['report_card_id' => $rc->id, 'grade_item_id' => $gi->id],
                    ['score' => $g->score, 'weight' => $gi->weight]
                );
                $total += ($g->score * ($gi->weight ?? 0));
                $weights += ($gi->weight ?? 0);
            }
            if ($weights > 0) {
                $rc->final_score = round($total / $weights, 2);
                $rc->save();
            }
        }
    }
}

